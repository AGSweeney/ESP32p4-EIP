#ifndef LWIP_SOCKET_EXAMPLES_H
#define LWIP_SOCKET_EXAMPLES_H

void socket_examples_init(void);

#endif /* LWIP_SOCKET_EXAMPLES_H */
